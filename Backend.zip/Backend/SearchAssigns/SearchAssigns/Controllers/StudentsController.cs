﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SearchAssigns.Models;
using System.Data;
using SearchAssigns.BusinessLayer;

namespace SearchAssigns.Controllers
{
    public class UsersController : ApiController
    {
        public BL businessLayer = new BL();

        [HttpGet]
        [Route("GetUsers")]
        public List<students> GetUsers()
        {
            try
            {
                List<students> Students = new List<students>();
                Students = businessLayer.GetAllStudents();
                return Students;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfUsers due to "
                   + exception.Message, exception.InnerException);
            }
        }
    }
}