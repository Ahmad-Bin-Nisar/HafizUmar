﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using SearchAssigns.Models;

namespace SearchAssigns.DataLayer
{
    public class DL
    {
        string _connectionString = "";

        public DL()
        {
            _connectionString = WebConfigurationManager.ConnectionStrings["DemoCN"].ConnectionString;
        }

        public DataTable GetAllStudents()
        {
            try
            {
                DataTable dataTable = new DataTable();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("GetAllStudents", con);
                    command.CommandType = CommandType.StoredProcedure;

                    con.Open();

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                    dataAdapter.Fill(dataTable);
                    con.Close();
                }
                return dataTable;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfUsers due to "
                   + exception.Message, exception.InnerException);
            }
        }

    }
}