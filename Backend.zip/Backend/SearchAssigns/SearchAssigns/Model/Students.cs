﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SearchAssigns.Models
{
    public class students
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public bool Complete { get; set; }
        public DateTime? ExpiryTime { get; set; }
        //public int StudentID { get; set; }
        //public string FirstName { get; set; }
        //public string LastName { get; set; }
        //public int Age { get; set; }
        //public string Course { get; set; }


    }
}