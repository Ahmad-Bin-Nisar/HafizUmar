﻿using SearchAssigns.DataLayer;
using SearchAssigns.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Security.Claims;
using System.Text;


namespace SearchAssigns.BusinessLayer
{
    public class BL
    {
        public DL dataLayer = new DL();
        public List<students> GetAllStudents()
        {
            try
            {
                DataTable table = new DataTable();
                List<students> listStudents = new List<students>();
                table = dataLayer.GetAllStudents();

                if (table != null && table.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in table.Rows)
                    {
                        students student = new students();
                        student.Id = Convert.ToInt32(dataRow["Id"]);
                        student.Description = dataRow["Description"].ToString();
                        student.Complete = Convert.ToBoolean(dataRow["Complete"]);
                        student.ExpiryTime = dataRow["ExpiryTime"] != DBNull.Value ? Convert.ToDateTime(dataRow["ExpiryTime"]) : (DateTime?)null;
                        //student.Course = dataRow["Course"].ToString();

                        listStudents.Add(student);
                    }
                }
                return listStudents;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfUsers due to "
                   + exception.Message, exception.InnerException);
            }
        }
    }
}